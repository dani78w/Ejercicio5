package com.example.ejercio5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.core.widget.doAfterTextChanged
import androidx.core.widget.doOnTextChanged

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var button: Button = findViewById(R.id.button)
        var editText: EditText = findViewById(R.id.editTextTextPersonName)
        var editText2: EditText = findViewById(R.id.editTextTextPersonName2)
        var textView:TextView = findViewById(R.id.textView)
        var textView2:TextView = findViewById(R.id.textView2)

        var flag = false
        var flag2 = false

        button.isEnabled = false
        var textoJunto=""

        textView2.setText("Nada en foco")

        button.setOnFocusChangeListener { v, hasFocus ->
            if(hasFocus){
                textView2.setText("Button en foco")
            }
        }
        editText.setOnFocusChangeListener { v, hasFocus ->
            if(hasFocus){
                textView2.setText("EditText en foco")
            }
        }
        editText2.setOnFocusChangeListener { v, hasFocus ->
            if(hasFocus){
                textView2.setText("EditText2 en foco")
            }
        }

        editText.doOnTextChanged { text, start, count, after ->
            flag = true

            if (editText.text.isEmpty()) {
                flag = false
            }else if(!editText2.text.isEmpty()){
                textoJunto=editText.text.toString()+editText2.text.toString()

            }

            if (flag && flag2) {
                button.isEnabled = true
            }
        }

        editText2.doOnTextChanged { text, start, count, after ->
            flag2 = true
            if (editText2.text.isEmpty()) {
                flag2 = false
            }else if(!editText.text.isEmpty()){
                textoJunto=editText.text.toString()+editText2.text.toString()
            }

            if (flag && flag2) {
                button.isEnabled = true
            }
        }

        button.setOnClickListener {
            textView.setText(textoJunto)
            editText.setText("")
            editText2.setText("")
            button.isEnabled = false
        }


    }

}




